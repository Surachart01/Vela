export const environment = {
  //  socketEndpoint: 'ws://10.0.0.100:9631',
  // socketEndpoint: 'http://localhost:4300',
  // socketEndpoint: 'https://api-thailandia-production.up.railway.app',

  appVersion: '2.0.0',
  AUTH_KEY: 'auth-token',
  USER_KEY: 'user-data',
  ROUTE_KEY: 'route-path',
  VALIDATE_KEY: 'validate',
  PROGRAM_ID: 1,
  apiUrl: 'http://localhost:4300/api/v1',
  // apiUrl: 'https://api-thailandia-production.up.railway.app/api/v1',

};
